package fr.rbo.exemple.db;

public interface DbContract {
    public static final String HOST = "jdbc:postgresql://localhost:5432/";
    public static final String DB_NAME = "try_postgres";
    public static final String USERNAME = "postgres";
    public static final String PASSWORD = "12az34er";
}

package fr.rbo.exemple.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import fr.rbo.exemple.db.DbContract;
import fr.rbo.exemple.db.PostgresHelper;

public class Main {

    public static void main(String[] args) throws SQLException {

        PostgresHelper client = new PostgresHelper(
                DbContract.HOST,
                DbContract.DB_NAME,
                DbContract.USERNAME,
                DbContract.PASSWORD);

        try {
            if (client.connect()) {
                System.out.println("DB connected");
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

//        ResultSet rs = client.execQuery("SELECT * FROM people");
        ResultSet rs = client.execQuery("SELECT id, name, surname, age FROM people");

        while(rs.next()) {

            System.out.printf("%d\t%s\t%s\t%d\n",
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("surname"),
                    rs.getInt("age"));
        }

    }
}

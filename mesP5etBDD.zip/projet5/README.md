# OCR - Cursus Developpeur d'Applications JAVA - Projet5
## Introduction
Ce projet consiste en une utilisation 'simple' de Spring Data JPA Hibernate pour créer un jeu de données de test dains une BdD MySQL

## Configuration
Les éléments de configuration propres à la BdD sont dans le fichier persistence.xml. Si la base doit être remplacée par une autre, d'un autre type, il conviendra de modifier le nom du driver, l'url de connexion et le nom du dialiecte généré par Hibernate.

package fr.rbo.oc05.domain.organisation.model;

public enum VisibilityType {
    Boutique, Enseigne
}

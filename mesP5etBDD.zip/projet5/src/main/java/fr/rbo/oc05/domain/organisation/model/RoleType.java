package fr.rbo.oc05.domain.organisation.model;

public enum RoleType {
    Cuisiner, Comptable, Logistique, ServiceClient, Livreur
}

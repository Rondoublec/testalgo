package fr.rbo.oc05.domain.commande.model;

public enum CommandeStatus {
    Enregistree, EnCours, Annulee, ALivrer, EnLivraison, Terminee, Archivee
}

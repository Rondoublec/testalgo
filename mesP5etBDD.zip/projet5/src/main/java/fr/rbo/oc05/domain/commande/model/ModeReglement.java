package fr.rbo.oc05.domain.commande.model;

public enum ModeReglement {
    EnLigne, EnBoutique, ADomicile
}

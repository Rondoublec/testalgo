package fr.rbo.oc05.domain.commande.repository;

import fr.rbo.oc05.domain.commande.model.Produit;

public interface ProduitRepository extends CommunRepository<Produit, Long> {
}

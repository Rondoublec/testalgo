package fr.rbo.oc05.domain.commande.repository;

import fr.rbo.oc05.domain.commande.model.Cuisinier;

public interface CuisinierRepository extends CommunRepository<Cuisinier, Long> {
}

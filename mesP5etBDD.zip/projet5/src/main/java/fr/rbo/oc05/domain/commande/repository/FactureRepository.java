package fr.rbo.oc05.domain.commande.repository;

import fr.rbo.oc05.domain.commande.model.Facture;

public interface FactureRepository extends CommunRepository<Facture, Long> {
}

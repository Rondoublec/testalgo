package fr.rbo.oc05.domain.organisation.repository;

import fr.rbo.oc05.domain.organisation.model.Adresse;

public interface AdresseRepository extends CommunRepository<Adresse, Long> {
}

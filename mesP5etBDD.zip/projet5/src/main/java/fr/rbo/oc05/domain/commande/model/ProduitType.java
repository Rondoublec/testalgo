package fr.rbo.oc05.domain.commande.model;

public enum ProduitType {
    ProduitPreparé, Boisson, ProduitSec, Dessert
}

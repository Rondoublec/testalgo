package fr.rbo.oc05.domain.organisation.repository;

import fr.rbo.oc05.domain.organisation.model.Role;

public interface RoleRepository extends CommunRepository<Role, Long> {
}

package fr.rbo.oc05.domain.commande.repository;

import fr.rbo.oc05.domain.commande.model.Client;

public interface ClientRepository extends CommunRepository<Client, Long> {
}

package fr.rbo.oc05.domain.commande.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import fr.rbo.oc05.domain.commande.model.CBoutique;

public interface CBoutiqueRepository extends CommunRepository<CBoutique, Long> {
}
